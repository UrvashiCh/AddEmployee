package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Employee;
import com.cg.repository.EmployeeRepository;

@RestController
@RequestMapping(value="/employee/")
@CrossOrigin(origins="http://localhost:4200")
public class EmployeeController {

	@Autowired
	EmployeeRepository repo;
	
	@PostMapping(value="/addEmployee",consumes=MediaType.APPLICATION_JSON_VALUE)
	public Employee add(@RequestBody Employee emp)
	{
		repo.save(emp);
		return emp;
	}
	
	

}
