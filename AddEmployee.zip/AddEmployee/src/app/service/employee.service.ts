import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../model/employee';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  url: string = 'http://localhost:1111/employee/addEmployee';
 

  constructor(private http: HttpClient) {}
   

   createEmployee(employee: Employee):Observable<any>
   {
     return this.http.post(this.url,employee);

    }

  }
