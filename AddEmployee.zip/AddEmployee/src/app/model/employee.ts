export class Employee {

    empId: number;
  
    empName: String;
  
    empPAN: String;
  
    empDesg: String;
  
    empDomain: String;
  
    empDOJ: Date;
  
    empDOB: Date;
  
    empSal: number;
  
    empMail: String;
  
    empPassword: String;
  
  }
  
  