import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee';
import { EmployeeService } from 'src/app/service/employee.service';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  emp: Employee={
    empId: 0,
  
    empName: ' ',
  
    empPAN: ' ',
  
    empDesg: ' ',
  
    empDomain: ' ',
  
    empDOJ: null,
  
    empDOB: null,
  
    empSal: 0,
  
    empMail: ' ',
  
    empPassword: ' '};
  constructor(private service: EmployeeService) { }

  ngOnInit() {
  }

  add()
  {
    this.service.createEmployee(this.emp)
     .subscribe(
       success => alert("Done"),
       error => alert(error)
     );
  }
}
