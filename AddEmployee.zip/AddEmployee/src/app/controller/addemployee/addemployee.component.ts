import { Component, OnInit } from '@angular/core';
import { Employee } from 'src/app/model/employee';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {
  emp: Employee={
    empId: 0,
  
    empName: ' ',
  
    empPAN: ' ',
  
    empDesg: ' ',
  
    empDomain: ' ',
  
    empDOJ: null,
  
    empDOB: null,
  
    empSal: 0,
  
    empMail: ' ',
  
    empPassword: ' '};
  constructor() { }

  ngOnInit() {
  }

  add()
  {}
}
